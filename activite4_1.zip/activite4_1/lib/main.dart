import 'package:flutter/material.dart';

void main() {
  runApp(const MonAppli());
}

 class MonAppli extends StatelessWidget {
  const MonAppli({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Magazine',
      home: const PageAcceuil(),
    );
  }
}

class PageAcceuil extends StatelessWidget {
  const PageAcceuil({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Colors.pink,
        title: Text('Magazine infos', ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {}, 
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {}, 
            ),
        ],
      ),
      body: Center(
        child: Image(
          image: AssetImage('assets/images/magazineInfos0.jpg'),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        foregroundColor: Colors.white,
        backgroundColor: Colors.pink,
        onPressed: () {
          //SnackBar affiche un message temporaire en bas de l'écran
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              backgroundColor: Color.fromARGB(255, 187, 0, 62),
              content: Text('Tu as cliqué dessus'),
            ),
          );
        },
        child: Text('Click'),
        ),
    );
  }
}
