# 📱 Magazine Infos – Application Flutter (Activité4_1)



## 📖 Présentation



**Magazine Infos** est une application mobile réalisée avec **Flutter** dans le cadre de l'**Activité n°4 du cours de Développement Mobile – Niveau intermédiaire** Dclic.



L'objectif de cette activité est de mettre en pratique les bases (Widgets) de la création d'interfaces mobiles avec Flutter, notamment l'utilisation de  `Image`, `Container`, `Row`, `Column`, `Text`, `Image`, `Icon`, `IconButton`, `FloatingActionButton`, etc.



---



## 🎯 Objectifs



Cette activité permet de :



- Créer une première application avec Flutter.

- Comprendre la structure d'un projet Flutter.

- Utiliser `MaterialApp` et `Scaffold`.

- Créer une barre d'application avec `AppBar`.

- Ajouter des images locales dans une application.

- Utiliser des widgets `StatelessWidget`.

- Organiser une interface avec `Row` et `Column`.

- Ajouter des icônes et des boutons.

- Améliorer progressivement l'organisation du code.



---



## 🛠️ Technologies utilisées



- **Flutter**

- **Dart**

- **GitHub**



---
