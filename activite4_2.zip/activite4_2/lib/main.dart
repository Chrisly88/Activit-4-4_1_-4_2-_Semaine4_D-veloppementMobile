import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MonAppli());
}
//Ici commence les classes de la page d'accueil du magazine

// classe PartieTitre (Titre et sous titre), 1er classe
 class PartieTitre extends StatelessWidget {
  const PartieTitre({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 20),
      child:  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Titre du magazine
            Text('Bienvenu au Magazine Infos',
              style: GoogleFonts.montserrat(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ), 
          
            //Sous titre du magazine
            Text("Votre magazine numérique, votre source d'inspiration et de divertissement.",
              style: GoogleFonts.poppins(
                fontSize: 12,
                color: const Color.fromARGB(255, 66, 66, 66),
              ),
            ),
        ],
      ),
    );
  }
}

//Classe PartieTexte (texte descriptif), 2eme classe
 
class PartieTexte extends StatelessWidget {
  const PartieTexte({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 20),
      //Text descriptif du magazine
      child:  Text(
       'Magazine Infos est un magazine numérique consacré à l’actualité, à la culture et au divertissement. Il propose à ses lecteurs des informations intéressantes, des articles variés et des contenus inspirants, accessibles à tout moment depuis leur téléphone ou leur tablette.', 
        textAlign: TextAlign.justify, style: GoogleFonts.poppins(),
      ),
    );
  }
}

// Classe Partie Icone, 3 eme classe
class PartieIcone extends StatelessWidget {
  const PartieIcone({super.key});
 
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row( 
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Container( 
              child: Column(
                children: [
                  Icon(Icons.phone, color: Colors.pink),
                  SizedBox(height: 5),
                  Text('TEL', style: GoogleFonts.nunitoSans(
                    fontSize: 12,
                    color: Colors.pink,
                    fontWeight: FontWeight.bold
                  )),
                ]
              )
            ),

            Container(
              child: Column(
                children: [
                  Icon(Icons.email, color: Colors.pink),
                  SizedBox(height: 5),
                  Text('EMAIL', style: GoogleFonts.nunitoSans(
                    fontSize: 12,
                    color: Colors.pink,
                    fontWeight: FontWeight.bold
                  )),
                ]
              )
            ),

            Container(
              child: Column(
                children: [
                  Icon(Icons.share, color: Colors.pink),
                  SizedBox(height: 5),
                  Text('PARTAGE', style: GoogleFonts.nunitoSans(
                    fontSize: 12,
                    color: Colors.pink,
                    fontWeight: FontWeight.bold
                  )),
                ]
              )
            ),
          ],
      ),
    );
  }
}

//Classe PartieRubrique, 4 eme classe
class PartieRubrique extends StatelessWidget {
  const PartieRubrique({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          
          //ClipRRect 1
          ClipRRect(
           borderRadius:  BorderRadius.circular(10.0),
           child: SizedBox(
            width: 100,
            height: 80,
            child: Image(
            image: AssetImage(
            'assets/images/mode.jpg', 
              ),
              fit: BoxFit.cover,
            ),
           ),
          ),
          //ClipRRect 2
          ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: SizedBox(
              width: 100,
              height: 80,
              child: Image(
              image: AssetImage(
                'assets/images/presse.jpg'
                ), 
                fit: BoxFit.cover,
              ),
            ),
          ),
        ], 
      ),
    );
  }
}

//Ici prend fin les classes de la magazine infos



//classe MonAppli contenant MaterialApp et la page d'accueil
 class MonAppli extends StatelessWidget {
  const MonAppli({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Magazine',
      home: const PageAcceuil(),
    );
  }
}

//classe de la page d'acceuil (PageAcceuill) contenant Scaffold et AppBar
class PageAcceuil extends StatelessWidget {
  const PageAcceuil({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white, //couleur de texte 
        backgroundColor: Colors.pink,
        title: Text('Magazine infos', ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {}, 
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {}, 
            ),
        ],
      ),
      body: const Column(
        children: [
          //code de la partie image
          Image(
              width: double.infinity,
              height: 270,
              fit: BoxFit.cover,     
              image: AssetImage('assets/images/magazineInfos0.jpg'),
              ),

      //petite espacement entre la photo et le titre
          SizedBox(height: 5,),
          PartieTitre(),

          SizedBox(height: 10),
          PartieTexte(),

          SizedBox(height: 10),
          PartieIcone(),

          SizedBox(height: 10),
          PartieRubrique(),
        ],
      ),
    
      floatingActionButton: FloatingActionButton(
        foregroundColor: Colors.white,
        backgroundColor: Colors.pink,
        onPressed: () {
          //SnackBar affiche un message temporaire en bas de l'écran
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              backgroundColor: Color.fromARGB(255, 187, 0, 62),
              content: Text('Tu as cliqué dessus'),
            ),
          );
        },
        child: Text('Click'),
        ),
    );
  }
}
